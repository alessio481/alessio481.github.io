# Godot Firebase

A Google Firebase SDK written in GDScript for use in Godot Engine projects. For more information about usage, support, and contribution, check out the [GitHub Repository](https://github.com/WolfgangSenff/GodotFirebase) and the [Wiki](https://github.com/WolfgangSenff/GodotFirebase/wiki).
